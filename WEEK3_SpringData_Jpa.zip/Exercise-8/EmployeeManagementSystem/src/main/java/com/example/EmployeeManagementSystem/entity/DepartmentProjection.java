package com.example.EmployeeManagementSystem.entity;

public interface DepartmentProjection {
    String getName();
}
